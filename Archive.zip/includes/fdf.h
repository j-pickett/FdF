/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fdf.h                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: apickett <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/07/16 18:03:20 by apickett          #+#    #+#             */
/*   Updated: 2018/08/25 21:28:23 by apickett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FDF_H
# define FDF_H

# define WW 1500
# define WH 750
# include "../mlx/mlx.h"
# include "../libft/libft.h"
# include "../gnl/gnl.h"
# include <math.h>
# include <stdio.h>

typedef struct		s_point
{
	float			x;
	float			y;
	float			z;
}					t_point;

typedef struct		s_stat
{
	float			h;
	float			w;
}					t_stat;

typedef struct		s_view
{
	void			*mlx;
	void			*window;
	void			*image;
	float			width;
	float			height;
	char			*name;
	int				bpp;
	int				sl;
	int				edian;
	int				scalex;
	int				scaley;
	int				fd;
	int				color;
	int				new_color;
	t_point			**map;
	t_stat			*stats;
}					t_view;

typedef	struct		s_rotation
{
	float			x;
	float			y;
	float			z;
	float			d;
	float			theta;
}					t_rotation;

typedef	struct		s_helper
{
	float			delta;
	float			error;
	float			slope;
	float			sum;
	float			temp;
	int				count;
	int				dir;
	int				fd;
	int				i;
	int				l;
	int				x;
	int				y;
	int				*ptr;
	int				yellow;
	int				pink;
	char			*ret;
	char			*line;
	t_point			**map;
}					t_helper;

t_point				*ft_center(t_view *view);
void				ft_storecoord(t_stat *stat, char **r_p, t_view *view);
void				ft_rdcd(char *s, int h, t_view *view, t_stat *stat);
char				*ft_readfile(int fd, t_view *view, t_stat *stat);
int					swap_var(t_point p0, t_point p1);
void				ft_drawline(t_view *view, t_point p0, t_point p1);
void				ft_drawline_y(t_view *view, t_point p0, t_point p1);
void				ft_scalecoord(t_view *view, t_stat *stat);
void				draw_w(float delta, t_view *view, int x, int y);
void				draw_h(float delta, t_view *view, int x, int y);
void				addpixels(t_view *view, t_stat *stat);
float				get_m_y(t_view *view);
float				get_m_x(t_view *view);
float				get_m_z(t_view *view);
void				ft_xrot(t_view *view, float rad);
void				ft_padding(t_view *view);
int					checkkey(int key, t_view *view);
int					ft_error_check(t_view *view, int fd);
void				toggle_color(t_view *view);
void				ft_gui(t_view *view);
void				ft_call(t_view *view);
void				initview(t_view *view, t_stat *stat);
int					checkex(t_view *view);
#endif
