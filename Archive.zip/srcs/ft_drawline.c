/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_drawline.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: apickett <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/14 19:43:41 by apickett          #+#    #+#             */
/*   Updated: 2018/08/14 19:43:43 by apickett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

int		swap_var(t_point p0, t_point p1)
{
	t_helper *head;

	head = malloc(sizeof(t_helper));
	if (fabs(p1.x - p0.x) > fabs(p1.y - p0.y))
		return (0);
	head->temp = p0.y;
	p0.y = p0.x;
	p0.x = head->temp;
	head->temp = p1.y;
	p1.y = p1.x;
	p1.x = head->temp;
	return (1);
	free(head);
}

void	ft_drawline(t_view *view, t_point p0, t_point p1)
{
	float		delta[3];
	t_helper	*head;

	head = malloc(sizeof(t_helper));
	head->dir = swap_var(p0, p1);
	head->yellow = 0xFFFF00;
	delta[0] = p1.x - p0.x;
	delta[1] = p1.y - p0.y;
	delta[2] = p1.z - p0.z;
	head->slope = fabs(delta[1] / delta[0]);
	head->error = -1.0;
	while ((int)p0.x != (int)p1.x && ft_error_check(view, 1))
	{
		mlx_pixel_put(view->mlx,
		view->window, head->dir ? p0.y : p0.x, head->dir ?
			p0.x : p0.y, head->yellow);
		head->error += head->slope;
		if (head->error >= 0.0 && ft_error_check(view, 1))
		{
			p0.y += (p0.y > p1.y) ? -1.0 : 1.0;
			head->error -= 1.0;
		}
		p0.x += (p0.x > p1.x) ? -1.0 : 1.0;
	}
	free(head);
}

void	ft_drawline_y(t_view *view, t_point p0, t_point p1)
{
	float		delta[3];
	t_helper	*head;

	head = malloc(sizeof(t_helper));
	head->dir = swap_var(p0, p1);
	head->yellow = 0xFFFF00;
	delta[0] = p1.y - p0.y;
	delta[1] = p1.x - p0.x;
	delta[2] = p1.z - p0.z;
	head->slope = fabs(delta[1] / delta[0]);
	head->error = -1.0;
	while ((int)p0.y != (int)p1.y && ft_error_check(view, 1))
	{
		mlx_pixel_put(view->mlx,
		view->window, head->dir ? p0.x : p0.y, head->dir ?
			p0.y : p0.x, head->yellow);
		head->error += head->slope;
		if (head->error >= 0.0 && ft_error_check(view, 1))
		{
			p0.x += (p0.x > p1.x) ? -1.0 : 1.0;
			head->error -= 1.0;
		}
		p0.y += (p0.y > p1.y) ? -1.0 : 1.0;
	}
	free(head);
}

void	draw_w(float delta, t_view *view, int x, int y)
{
	if (delta < 1.0f && ft_error_check(view, 1))
		ft_drawline_y(view, view->map[y][x], view->map[y][x + 1]);
	else
		ft_drawline(view, view->map[y][x], view->map[y][x + 1]);
}

void	draw_h(float delta, t_view *view, int x, int y)
{
	if (delta >= 1.0f && ft_error_check(view, 1))
		ft_drawline_y(view, view->map[y][x], view->map[y + 1][x]);
	else
		ft_drawline_y(view, view->map[y][x], view->map[y + 1][x]);
}
