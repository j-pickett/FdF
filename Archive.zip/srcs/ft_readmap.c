/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_readmap.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: apickett <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/14 19:43:54 by apickett          #+#    #+#             */
/*   Updated: 2018/08/14 19:43:55 by apickett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

void	ft_storecoord(t_stat *stat, char **r_p, t_view *view)
{
	t_helper *head;

	head = malloc(sizeof(t_helper));
	head->x = 0;
	head->y = 0;
	head->i = 0;
	while (head->y < stat->h && ft_error_check(view, 1))
	{
		while (head->x < stat->w && ft_error_check(view, 1))
		{
			view->map[head->y][head->x].x = (float)head->x;
			view->map[head->y][head->x].y = (float)head->y;
			view->map[head->y][head->x].z = (float)ft_atoi(r_p[head->i]);
			head->x++;
			head->i++;
		}
		head->y++;
		head->x = 0;
	}
}

void	ft_rdcd(char *s, int h, t_view *view, t_stat *stat)
{
	t_helper *head;

	head = malloc(sizeof(t_helper));
	head->i = 0;
	head->l = stat->w;
	stat->h = h;
	view->map = (t_point**)malloc(sizeof(t_point*) * h);
	ft_bzero(view->map, sizeof(t_point*) * h);
	while (head->i < stat->h && ft_error_check(view, 1))
	{
		view->map[head->i] = (t_point*)malloc(sizeof(t_point) * head->l);
		ft_bzero(view->map[head->i], sizeof(t_point) * head->l);
		head->i++;
	}
	ft_storecoord(stat, ft_strsplit(s, ' '), view);
	free(head);
}

char	*ft_readfile(int fd, t_view *view, t_stat *stat)
{
	t_helper *head;

	head = malloc(sizeof(t_helper));
	head->count = 0;
	while (get_next_line(fd, &head->line) && ft_error_check(view, 1))
	{
		if (head->count == 0 && ft_error_check(view, 1))
		{
			head->ret = ft_strdup(head->line);
			stat->w = ft_intcount(ft_strsplit(head->ret, ' '));
		}
		else
		{
			head->ret = ft_strjoin(head->ret, " ");
			head->ret = ft_strjoin(head->ret, head->line);
		}
		if (ft_intcount(ft_strsplit(head->line, ' ')) != stat->w)
			ft_error_check(view, 1);
		head->count++;
	}
	ft_rdcd(head->ret, head->count, view, stat);
	return (head->ret);
}
