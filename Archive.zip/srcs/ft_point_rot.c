/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_point_rot.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: apickett <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/14 19:48:13 by apickett          #+#    #+#             */
/*   Updated: 2018/08/14 19:48:15 by apickett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

void		ft_scalecoord(t_view *view, t_stat *stat)
{
	t_helper	*head;
	int			mx;
	int			my;

	head = malloc(sizeof(t_helper));
	mx = get_m_x(view);
	my = get_m_y(view);
	head->x = 0;
	head->y = 0;
	while (head->y < stat->h && ft_error_check(view, 1))
	{
		while (head->x < stat->w && ft_error_check(view, 1))
		{
			view->map[head->y][head->x].x *= ((view->height / stat->h) / 2);
			view->map[head->y][head->x].y *= ((view->height / stat->h) / 2);
			view->map[head->y][head->x].z *= ((view->width / stat->w) / 2);
			head->x++;
		}
		head->x = 0;
		head->y++;
	}
}

t_point		*ft_center(t_view *view)
{
	t_point *ret;

	ret = (t_point*)malloc(sizeof(t_point));
	ft_bzero(ret, sizeof(t_point));
	ret->x = get_m_x(view);
	ret->y = get_m_y(view);
	ret->z = get_m_z(view);
	return (ret);
}

void		ft_xrot(t_view *view, float rad)
{
	t_helper	*head;
	t_rotation	r_points;
	t_point		*middle;

	head = malloc(sizeof(t_helper));
	middle = ft_center(view);
	head->y = 0;
	while (head->y < view->stats->h && ft_error_check(view, 1))
	{
		head->x = 0;
		while (head->x < view->stats->w && ft_error_check(view, 1))
		{
			r_points.y = view->map[head->y][head->x].y - middle->y;
			r_points.z = view->map[head->y][head->x].z - middle->z;
			r_points.d = hypot(r_points.y, r_points.z);
			r_points.theta = atan2(r_points.y, r_points.z) + rad;
			view->map[head->y][head->x].z = r_points.d *
			cos(r_points.theta) + middle->z;
			view->map[head->y][head->x].y = r_points.d *
			sin(r_points.theta) + middle->y;
			head->x++;
		}
		head->y++;
	}
}

void		ft_padding(t_view *view)
{
	t_helper *head;

	head = malloc(sizeof(t_helper));
	head->y = 0;
	while (head->y < view->stats->h && ft_error_check(view, 1))
	{
		head->x = 0;
		while (head->x < view->stats->w && ft_error_check(view, 1))
		{
			view->map[head->y][head->x].x += (view->width) / 4;
			view->map[head->y][head->x].y += (view->height) / 4;
			head->x++;
		}
		head->y++;
	}
}

int			checkex(t_view *view)
{
	t_helper *head;

	head = malloc(sizeof(t_helper));
	addpixels(view, view->stats);
	while (head->i < view->fd)
		head->i++;
	if (head->i < 0)
		return (0);
	return (0);
}
