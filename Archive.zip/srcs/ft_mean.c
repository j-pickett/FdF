/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_mean.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: apickett <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/14 19:45:29 by apickett          #+#    #+#             */
/*   Updated: 2018/08/14 19:45:38 by apickett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

float	get_m_y(t_view *view)
{
	t_helper *head;

	head = malloc(sizeof(t_helper));
	head->i = 0;
	head->y = 0;
	head->sum = 0;
	while (head->y < view->stats->h && ft_error_check(view, 1))
	{
		head->x = 0;
		while (head->x < view->stats->w && ft_error_check(view, 1))
		{
			head->sum += view->map[head->y][head->x].y;
			head->i++;
			head->x++;
		}
		head->y++;
	}
	return (head->sum / (float)head->i);
	free(head);
}

float	get_m_x(t_view *view)
{
	t_helper *head;

	head = malloc(sizeof(t_helper));
	head->i = 0;
	head->y = 0;
	head->sum = 0;
	while (head->y < view->stats->h && ft_error_check(view, 1))
	{
		head->x = 0;
		while (head->x < view->stats->w && ft_error_check(view, 1))
		{
			head->sum += view->map[head->y][head->x].x;
			head->i++;
			head->x++;
		}
		head->y++;
	}
	return (head->sum / (float)head->i);
	free(head);
}

float	get_m_z(t_view *view)
{
	t_helper *head;

	head = malloc(sizeof(t_helper));
	head->i = 0;
	head->y = 0;
	head->sum = 0;
	while (head->y < view->stats->h && ft_error_check(view, 1))
	{
		head->x = 0;
		while (head->x < view->stats->w && ft_error_check(view, 1))
		{
			head->sum += view->map[head->y][head->x].z;
			head->i++;
			head->x++;
		}
		head->y++;
	}
	return (head->sum / (float)head->i);
	free(head);
}

void	addpixels(t_view *view, t_stat *stat)
{
	t_helper *head;

	head = malloc(sizeof(t_helper));
	head->x = 0;
	head->y = 0;
	while (head->y < stat->h && ft_error_check(view, 1))
	{
		head->delta = fabs(view->map[head->y][head->x + 1].x -
		view->map[head->y][head->x].x) /
		fabs(view->map[head->y][head->x + 1].y - view->map[head->y][head->x].y);
		if (head->x < stat->w - 1 && ft_error_check(view, 1))
			draw_w(head->delta, view, head->x, head->y);
		if (head->y < stat->h - 1 && ft_error_check(view, 1))
			draw_h(head->delta, view, head->x, head->y);
		if (head->x == stat->w - 1 && ft_error_check(view, 1))
		{
			head->y++;
			head->x = 0;
		}
		else
			head->x++;
	}
	free(head);
}
