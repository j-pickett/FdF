/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: apickett <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/14 19:35:31 by apickett          #+#    #+#             */
/*   Updated: 2018/08/14 19:35:33 by apickett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"
#define NORM_LUL t_helper *head; t_view *view; t_stat *stat;

int		checkkey(int key, t_view *view)
{
	t_helper *head;

	head = malloc(sizeof(t_helper));
	if (key == 53 && ft_error_check(view, 1))
	{
		free(view);
		exit(1);
	}
	if (key == 8 && ft_error_check(view, 1) == 1)
	{
		view->color = (view->color + 1) % 5;
		toggle_color(view);
	}
	return (1);
	free(head);
}

void	initview(t_view *view, t_stat *stat)
{
	view->stats = stat;
	view->mlx = mlx_init();
	view->width = WW;
	view->height = WH;
}

int		ft_error_check(t_view *view, int fd)
{
	t_helper *head;

	head = malloc(sizeof(t_helper));
	head->i = 0;
	head->ptr = (int *)malloc(sizeof(int) * 10);
	if (fd == -1)
		return (0);
	if (view == 0)
	{
		ft_putendl("something fucked up");
		free(head->ptr);
		return (0);
	}
	if (view != 0)
	{
		head->ptr[head->i] = 0;
		head->i++;
	}
	view->fd += head->i - 1;
	free(head->ptr);
	return (1);
}

void	ft_call(t_view *view)
{
	ft_gui(view);
	ft_padding(view);
}

int		main(int argc, char *argv[])
{
	NORM_LUL;
	head = malloc(sizeof(t_helper));
	stat = (t_stat*)malloc(sizeof(t_stat));
	view = (t_view*)malloc(sizeof(t_view));
	ft_bzero(view, sizeof(t_view));
	ft_bzero(stat, sizeof(t_stat));
	if (argc == 2 && ft_error_check(view, 1))
	{
		head->fd = open(argv[1], O_RDONLY);
		ft_error_check(view, head->fd);
		ft_readfile(head->fd, view, stat);
	}
	else
		ft_error_check(view, 1);
	initview(view, stat);
	view->window = mlx_new_window(view->mlx, view->width, view->height, "FdF");
	ft_scalecoord(view, stat);
	ft_call(view);
	ft_xrot(view, -.2);
	addpixels(view, stat);
	mlx_key_hook(view->window, checkkey, view);
	mlx_expose_hook(view->window, checkex, view);
	mlx_loop(view->mlx);
	free(head);
}
