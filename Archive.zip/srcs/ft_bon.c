/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_bon.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: apickett <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/08/16 15:16:29 by apickett          #+#    #+#             */
/*   Updated: 2018/08/16 15:16:31 by apickett         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "fdf.h"

void	ft_gui(t_view *view)
{
	t_helper *head;

	head = malloc(sizeof(t_helper));
	head->pink = 0xFA69F0;
	head->yellow = 0xFFF100;
	mlx_string_put(view->mlx, view->window, 10, 0, head->yellow,
	"USER INPUT COMMANDS:");
	mlx_string_put(view->mlx, view->window, 10, 30, head->pink,
	"C: Change Colors");
	mlx_string_put(view->mlx, view->window, 10, 50, head->pink,
	"SPACEBAR: Change View");
	mlx_string_put(view->mlx, view->window, 10, 70, head->pink,
	"ARROW KEYS: Move Image Around");
	mlx_string_put(view->mlx, view->window, 10, 90, head->pink,
	"ESC: Close window");
}

void	toggle_color(t_view *view)
{
	if (view->color == 0 && ft_error_check(view, 1) == 1)
		view->new_color = 0xFFFFFF;
	if (view->color == 1 && ft_error_check(view, 1) == 1)
		view->new_color = 0xFA4822;
	if (view->color == 2 && ft_error_check(view, 1) == 1)
		view->new_color = 0x11C4C8;
	if (view->color == 3 && ft_error_check(view, 1) == 1)
		view->new_color = 0xFF5CF8;
	if (view->color == 4 && ft_error_check(view, 1) == 1)
		view->new_color = 0x37F83F;
}
